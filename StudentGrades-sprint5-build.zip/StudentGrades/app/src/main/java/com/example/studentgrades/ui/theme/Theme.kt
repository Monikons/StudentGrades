package com.example.studentgrades.ui.theme

import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle

/**
 * Цвета макета (docs/screen-graph-prototype.html, таблица в docs/design.md).
 * Менять значения только вместе с макетом.
 */
object AppColors {
    val Primary = Color(0xFF4F46E5)        // кнопки, большая карточка, активная вкладка
    val PrimaryDark = Color(0xFF3730A3)    // текст таблеток
    val PrimarySoft = Color(0xFFEEF2FF)    // фон таблеток, пустые подсказки
    val Background = Color(0xFFFAFAFC)     // фон экрана
    val Surface = Color(0xFFFFFFFF)        // строки, поля, диалоги
    val Border = Color(0xFFE5E7EB)         // рамки строк, линия над нижней навигацией
    val InputBorder = Color(0xFFD1D5DB)    // рамка полей ввода
    val Text = Color(0xFF111827)
    val TextSecondary = Color(0xFF374151)  // подписи, вторые строки
    val NavInactive = Color(0xFF4B5563)
    val ChartBar = Color(0xFF6366F1)
    val DialogText = Color(0xFF1F2937)
    val ButtonSecondaryText = Color(0xFF1F2937)
    val GoodBg = Color(0xFFBBF7D0)
    val GoodFg = Color(0xFF14532D)
    val LowFg = Color(0xFFB91C1C)
    val LowRowBg = Color(0xFFFEF2F2)
    val LowBg = Color(0xFFFEE2E2)
    val LowBorder = Color(0xFFFCA5A5)
    val WarnBg = Color(0xFFFEF3C7)
    val WarnFg = Color(0xFF92400E)
    val NeutralBg = Color(0xFFE5E7EB)      // плашка «—» (оценок нет)
    val NeutralFg = Color(0xFF374151)
    val Danger = Color(0xFFDC2626)
    val EmptyIcon = Color(0xFFE0E7FF)
    val Scrim = Color(0x73111827)          // rgba(17,24,39,.45)
}

private val AppTypography = Typography().let { t ->
    fun TextStyle.dark() = copy(color = AppColors.Text)
    t.copy(
        displayLarge = t.displayLarge.dark(), displayMedium = t.displayMedium.dark(), displaySmall = t.displaySmall.dark(),
        headlineLarge = t.headlineLarge.dark(), headlineMedium = t.headlineMedium.dark(), headlineSmall = t.headlineSmall.dark(),
        titleLarge = t.titleLarge.dark(), titleMedium = t.titleMedium.dark(), titleSmall = t.titleSmall.dark(),
        bodyLarge = t.bodyLarge.dark(), bodyMedium = t.bodyMedium.dark(), bodySmall = t.bodySmall.dark(),
        labelLarge = t.labelLarge.dark(), labelMedium = t.labelMedium.dark(), labelSmall = t.labelSmall.dark()
    )
}

private val Scheme = lightColorScheme(
    primary = AppColors.Primary,
    onPrimary = Color.White,
    background = AppColors.Background,
    onBackground = AppColors.Text,
    surface = AppColors.Surface,
    surfaceVariant = AppColors.Surface,
    onSurfaceVariant = AppColors.TextSecondary,
    onSurface = AppColors.Text,
    error = AppColors.Danger
)

@Composable
fun StudentGradesTheme(content: @Composable () -> Unit) {
    // Один и тот же цвет и насыщенность основного текста при любом состоянии системы
    MaterialTheme(colorScheme = Scheme, typography = AppTypography) {
        CompositionLocalProvider(LocalContentColor provides AppColors.Text) {
            ProvideTextStyle(TextStyle(color = AppColors.Text), content = content)
        }
    }
}
