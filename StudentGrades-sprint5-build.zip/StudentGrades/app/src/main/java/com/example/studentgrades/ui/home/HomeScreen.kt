package com.example.studentgrades.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.studentgrades.data.AppData
import com.example.studentgrades.domain.AverageFormatter
import com.example.studentgrades.domain.GradeCalculator
import com.example.studentgrades.ui.components.AppButton
import com.example.studentgrades.ui.components.ButtonKind
import com.example.studentgrades.ui.components.ListRow
import com.example.studentgrades.ui.components.gradesCount
import com.example.studentgrades.ui.theme.AppColors

/** Экран 1. Главная сводка. */
@Composable
fun HomeScreen(data: AppData, onOpenGrades: (Long) -> Unit, onOpenDbCheck: () -> Unit) {
    val overall = GradeCalculator.overallAverage(data.grades.map { it.value })

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 0.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(AppColors.Primary)
                    .padding(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Общий средний балл", color = Color.White.copy(alpha = 0.9f), fontSize = 15.sp)
                Text(
                    AverageFormatter.format(overall),
                    color = Color.White,
                    fontSize = 45.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    if (data.grades.isEmpty()) "Оценок пока нет"
                    else gradesCount(data.grades.size) + " · среднее арифм. по записям",
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
        items(data.disciplines, key = { it.id }) { d ->
            val avg = data.averageOf(d.id)
            ListRow(
                title = d.name,
                subtitle = gradesCount(data.gradesOf(d.id).size),
                chip = AverageFormatter.format(avg),
                low = GradeCalculator.isLow(avg),
                onClick = { onOpenGrades(d.id) }
            )
        }
        item {
            Text(
                "Красным — средний балл ниже 3,50",
                color = AppColors.LowFg,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
        }
        item {
            AppButton("Проверка базы данных (спринт 2)", onOpenDbCheck, Modifier.fillMaxWidth(), ButtonKind.Secondary)
        }
    }
}
