package com.example.studentgrades.domain

import java.math.BigDecimal
import java.math.RoundingMode

/** Результат расчёта «какая оценка нужна для целевого среднего». */
sealed interface TargetResult {
    /** Нужна оценка [grade] (целое от 2 до 5). */
    data class Needed(val grade: Int) : TargetResult

    /** Цель достигается даже с минимальной оценкой. */
    data object AlreadyAchieved : TargetResult

    /** Цель недостижима одной оценкой: нужно [required] (> 5), округлено вверх. */
    data class Unreachable(val required: Int) : TargetResult

    /** Цель вне допустимого диапазона 2–5. */
    data object InvalidTarget : TargetResult
}

object GradeCalculator {

    /** Среднее арифметическое, 2 знака, HALF_UP. null — если оценок нет (деления на ноль нет). */
    fun average(values: List<Int>): BigDecimal? {
        if (values.isEmpty()) return null
        return BigDecimal(values.sum())
            .divide(BigDecimal(values.size), GradeRules.AVERAGE_SCALE, RoundingMode.HALF_UP)
    }

    /** Общий средний: сумма всех оценок / число всех оценок (не среднее средних). */
    fun overallAverage(allValues: List<Int>): BigDecimal? = average(allValues)

    /** Низкий ли средний балл (null — оценок нет, не подсвечиваем). */
    fun isLow(average: BigDecimal?): Boolean =
        average != null && average < BigDecimal(GradeRules.LOW_AVERAGE_THRESHOLD)

    /**
     * Нужная следующая оценка = цель × (n + 1) − сумма, округление вверх до целого.
     * Пример: оценки 5,4,3,5 и цель 4,40 → 4,4 × 5 − 17 = 5.
     */
    fun requiredNextGrade(values: List<Int>, target: BigDecimal): TargetResult {
        if (target < BigDecimal(GradeRules.MIN_GRADE) || target > BigDecimal(GradeRules.MAX_GRADE)) {
            return TargetResult.InvalidTarget
        }
        val needed = target
            .multiply(BigDecimal(values.size + 1))
            .subtract(BigDecimal(values.sum()))
            .setScale(0, RoundingMode.CEILING)
            .toInt()
        return when {
            needed <= GradeRules.MIN_GRADE -> TargetResult.AlreadyAchieved
            needed > GradeRules.MAX_GRADE -> TargetResult.Unreachable(needed)
            else -> TargetResult.Needed(needed)
        }
    }

    /**
     * Сценарный расчёт: средний балл, если к оценкам [base] добавить оценки из [added]
     * (ключ — оценка 2–5, значение — сколько раз она получена). Оценок нет — null.
     */
    fun averageWithAdded(base: List<Int>, added: Map<Int, Int>): BigDecimal? {
        val extra = added.flatMap { (grade, count) -> List(count.coerceAtLeast(0)) { grade } }
        return average(base + extra)
    }
}
