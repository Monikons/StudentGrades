package com.example.studentgrades.ui.grades

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.example.studentgrades.ui.components.OptionalWorkTypeSaver
import com.example.studentgrades.ui.components.OptionalMonthSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.studentgrades.data.AppData
import com.example.studentgrades.domain.AverageFormatter
import com.example.studentgrades.domain.GradeRules
import com.example.studentgrades.domain.model.WorkType
import com.example.studentgrades.ui.components.AppButton
import com.example.studentgrades.ui.components.AppDropdown
import com.example.studentgrades.ui.components.ButtonKind
import com.example.studentgrades.ui.components.EmptyState
import com.example.studentgrades.ui.components.ListRow
import com.example.studentgrades.ui.components.Overlay
import com.example.studentgrades.ui.components.Pill
import com.example.studentgrades.ui.components.ScreenBar
import com.example.studentgrades.ui.components.ShortDateFormat
import com.example.studentgrades.ui.components.consumeTaps
import com.example.studentgrades.ui.components.monthLabel
import com.example.studentgrades.ui.theme.AppColors
import java.time.YearMonth

/** Экран 3. Оценки дисциплины (+ фильтры — экран 8, пустое состояние — экран 10). */
@Composable
fun GradesScreen(
    data: AppData,
    disciplineId: Long,
    onBack: () -> Unit,
    onAdd: (Long) -> Unit,
    onEdit: (Long, Long) -> Unit
) {
    var currentId by rememberSaveable(disciplineId) { mutableStateOf(disciplineId) }
    var workType by rememberSaveable(stateSaver = OptionalWorkTypeSaver) { mutableStateOf<WorkType?>(null) }
    var month by rememberSaveable(stateSaver = OptionalMonthSaver) { mutableStateOf<YearMonth?>(null) }
    var sortByValue by rememberSaveable { mutableStateOf(false) }
    var showFilters by rememberSaveable { mutableStateOf(false) }

    val discipline = data.discipline(currentId)
    val all = data.gradesOf(currentId)
    val months = all.map { YearMonth.from(it.date) }.distinct().sortedDescending()

    val shown = all
        .filter { workType == null || it.workType == workType }
        .filter { month == null || YearMonth.from(it.date) == month }
        .let { list ->
            if (sortByValue) list.sortedWith(compareByDescending { it.value })
            else list.sortedByDescending { it.date }
        }

    BackHandler(enabled = showFilters) { showFilters = false }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            ScreenBar(
                title = (discipline?.name ?: "Дисциплина") + " · " + AverageFormatter.format(data.averageOf(currentId)),
                onBack = onBack
            )
            if (all.isEmpty()) {
                EmptyState(
                    title = "Оценок пока нет",
                    text = "Средний балл появится после первой оценки",
                    buttonLabel = "Добавить оценку",
                    onClick = { onAdd(currentId) }
                )
            } else {
                Row(
                    Modifier.padding(start = 12.dp, end = 12.dp, bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    Pill("Фильтр") { showFilters = true }
                    Pill("Сортировка: " + if (sortByValue) "значение" else "дата") { sortByValue = !sortByValue }
                }
                if (shown.isEmpty()) {
                    EmptyState(
                        title = "Ничего не найдено",
                        text = "Измените фильтры или сбросьте их",
                        buttonLabel = "Сбросить",
                        onClick = { workType = null; month = null }
                    )
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 90.dp),
                        verticalArrangement = Arrangement.spacedBy(9.dp)
                    ) {
                        items(shown, key = { it.id }) { g ->
                            val note = if (g.comment.isNotEmpty()) " · «${g.comment}»" else ""
                            ListRow(
                                title = "${g.value} · ${g.workType.title}",
                                subtitle = g.date.format(ShortDateFormat) + note,
                                chip = g.value.toString(),
                                low = g.value <= GradeRules.MIN_GRADE,
                                onClick = { onEdit(currentId, g.id) }
                            )
                        }
                    }
                }
            }
        }
        if (all.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 18.dp, bottom = 18.dp)
                    .size(60.dp)
                    .clip(CircleShape)
                    .background(AppColors.Primary)
                    .clickable { onAdd(currentId) },
                contentAlignment = Alignment.Center
            ) { Text("+", color = Color.White, fontSize = 36.sp) }
        }

        if (showFilters) {
            Overlay(onDismiss = { showFilters = false }) {
                FiltersSheet(
                    data = data,
                    currentId = currentId,
                    months = months,
                    initialMonth = month,
                    initialType = workType,
                    initialSortByValue = sortByValue,
                    modifier = Modifier.align(Alignment.BottomCenter),
                    onApply = { id, m, t, s ->
                        currentId = id
                        month = m
                        workType = t
                        sortByValue = s
                        showFilters = false
                    }
                )
            }
        }
    }
}

/** Экран 8. Фильтры и сортировка (нижняя панель, .sheet). */
@Composable
private fun FiltersSheet(
    data: AppData,
    currentId: Long,
    months: List<YearMonth>,
    initialMonth: YearMonth?,
    initialType: WorkType?,
    initialSortByValue: Boolean,
    modifier: Modifier,
    onApply: (Long, YearMonth?, WorkType?, Boolean) -> Unit
) {
    var id by remember { mutableStateOf(currentId) }
    var m by remember { mutableStateOf(initialMonth) }
    var t by remember { mutableStateOf(initialType) }
    var s by remember { mutableStateOf(initialSortByValue) }

    // Периоды зависят от выбранной дисциплины
    val monthsOfSelected = if (id == currentId) months
    else data.gradesOf(id).map { YearMonth.from(it.date) }.distinct().sortedDescending()
    val monthOptions = listOf("Весь период") + monthsOfSelected.map { monthLabel(it) }
    val typeOptions = listOf("Все") + WorkType.values().map { it.title }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 21.dp, topEnd = 21.dp))
            .background(AppColors.Surface)
            .consumeTaps()
            .padding(15.dp)
    ) {
        Text("Фильтры", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = AppColors.Text)
        AppDropdown(
            "Дисциплина",
            data.discipline(id)?.name ?: "Все",
            data.disciplines.map { it.name },
            onSelect = { i -> id = data.disciplines[i].id; m = null }
        )
        AppDropdown(
            "Период",
            m?.let { monthLabel(it) } ?: "Весь период",
            monthOptions,
            onSelect = { i -> m = if (i == 0) null else monthsOfSelected[i - 1] }
        )
        AppDropdown(
            "Вид работы",
            t?.title ?: "Все",
            typeOptions,
            onSelect = { i -> t = if (i == 0) null else WorkType.values()[i - 1] }
        )
        AppDropdown(
            "Сортировка",
            if (s) "Значение" else "Дата",
            listOf("Дата", "Значение"),
            onSelect = { i -> s = i == 1 }
        )
        Row(
            Modifier.fillMaxWidth().padding(top = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            AppButton(
                "Сбросить",
                onClick = { m = null; t = null; s = false },
                modifier = Modifier.weight(1f),
                kind = ButtonKind.Secondary
            )
            AppButton("Применить", onClick = { onApply(id, m, t, s) }, modifier = Modifier.weight(1f))
        }
    }
}
