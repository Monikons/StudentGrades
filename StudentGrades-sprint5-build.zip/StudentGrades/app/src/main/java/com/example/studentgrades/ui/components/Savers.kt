package com.example.studentgrades.ui.components

import androidx.compose.runtime.saveable.Saver
import com.example.studentgrades.domain.model.WorkType
import java.time.YearMonth

/** Сохранение состояния экранов при повороте и восстановлении приложения (перечисления и месяц). */
val WorkTypeSaver = Saver<WorkType, String>(save = { it.name }, restore = { WorkType.valueOf(it) })

val OptionalWorkTypeSaver = Saver<WorkType?, String>(
    save = { it?.name ?: "" },
    restore = { if (it.isEmpty()) null else WorkType.valueOf(it) }
)

val OptionalMonthSaver = Saver<YearMonth?, String>(
    save = { it?.toString() ?: "" },
    restore = { if (it.isEmpty()) null else YearMonth.parse(it) }
)
