package com.example.studentgrades

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.studentgrades.ui.navigation.AppNavGraph
import com.example.studentgrades.ui.theme.StudentGradesTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Не даём системе принудительно затемнять/пересчитывать цвета (тёмная тема, экономия заряда)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.decorView.isForceDarkAllowed = false
        }
        setContent {
            StudentGradesTheme {
                AppNavGraph()
            }
        }
    }
}
