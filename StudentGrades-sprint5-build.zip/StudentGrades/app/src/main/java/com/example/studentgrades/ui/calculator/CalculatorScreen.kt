package com.example.studentgrades.ui.calculator

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.studentgrades.data.AppData
import com.example.studentgrades.domain.AverageFormatter
import com.example.studentgrades.domain.GradeCalculator
import com.example.studentgrades.domain.GradeRules
import com.example.studentgrades.domain.TargetResult
import com.example.studentgrades.ui.components.AppButton
import com.example.studentgrades.ui.components.AppDropdown
import com.example.studentgrades.ui.components.AppTextField
import com.example.studentgrades.ui.components.ButtonKind
import com.example.studentgrades.ui.components.Chip
import com.example.studentgrades.ui.components.EmptyState
import com.example.studentgrades.ui.components.ScreenBar
import com.example.studentgrades.ui.components.gradesCount
import com.example.studentgrades.ui.theme.AppColors

/**
 * Экран «Калькулятор»: два режима на одном экране.
 *  • «Средний балл» — сценарный прогноз: сколько оценок 2, 3, 4, 5 → средний балл (спринт 4);
 *  • «Целевой балл» — какая следующая оценка нужна для желаемого среднего (спринт 5).
 * Выбранный режим и введённые значения сохраняются при повороте экрана и восстановлении приложения.
 */
@Composable
fun CalculatorScreen(data: AppData) {
    var mode by rememberSaveable { mutableStateOf(0) } // 0 — средний, 1 — целевой

    Column(Modifier.fillMaxSize()) {
        ScreenBar("Калькулятор")
        ModeSwitch(
            options = listOf("Средний балл", "Целевой балл"),
            selected = mode,
            onSelect = { mode = it },
            modifier = Modifier.padding(horizontal = 12.dp).padding(bottom = 9.dp)
        )
        if (mode == 0) AverageCalculator(data) else TargetCalculator(data)
    }
}

/** Переключатель режимов (сегменты в стиле таблеток макета). */
@Composable
private fun ModeSwitch(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(AppColors.PrimarySoft)
            .border(1.dp, AppColors.Border, shape)
            .padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(9.dp))
                    .background(if (on) AppColors.Primary else Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (on) Color.White else AppColors.PrimaryDark,
                    maxLines = 1
                )
            }
        }
    }
}

/** Общий вид результата: крупная карточка (.res) трёх состояний. */
private enum class ResultTone { Info, Good, Warn }

@Composable
private fun ResultCard(title: String, value: String?, note: String, tone: ResultTone) {
    val bg = when (tone) { ResultTone.Info -> AppColors.Primary; ResultTone.Good -> AppColors.GoodBg; ResultTone.Warn -> AppColors.WarnBg }
    val fg = when (tone) { ResultTone.Info -> Color.White; ResultTone.Good -> AppColors.GoodFg; ResultTone.Warn -> AppColors.WarnFg }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(bg).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, color = fg, fontSize = 16.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        if (value != null) {
            Text(value, color = fg, fontSize = 45.sp, fontWeight = FontWeight.Bold)
        }
        Text(note, color = fg, fontSize = 15.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }
}

// ---------------------------------------------------------------- Средний балл (спринт 4)

@Composable
private fun AverageCalculator(data: AppData) {
    val grades = (GradeRules.MIN_GRADE..GradeRules.MAX_GRADE).toList().reversed() // 5, 4, 3, 2
    var c5 by rememberSaveable { mutableStateOf(0) }
    var c4 by rememberSaveable { mutableStateOf(0) }
    var c3 by rememberSaveable { mutableStateOf(0) }
    var c2 by rememberSaveable { mutableStateOf(0) }
    var baseIndex by rememberSaveable { mutableStateOf(0) } // 0 — без основы, дальше — дисциплины
    val counts = mapOf(5 to c5, 4 to c4, 3 to c3, 2 to c2)
    fun setCount(g: Int, v: Int) {
        val n = v.coerceIn(0, MAX_COUNT)
        when (g) { 5 -> c5 = n; 4 -> c4 = n; 3 -> c3 = n; else -> c2 = n }
    }

    val discipline = if (baseIndex == 0) null else data.disciplines.getOrNull(baseIndex - 1)
    val base: List<Int> = discipline?.let { d -> data.gradesOf(d.id).map { it.value } } ?: emptyList()

    val result = GradeCalculator.averageWithAdded(base, counts)
    val total = base.size + counts.values.sum()
    val current = GradeCalculator.average(base)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        AppDropdown(
            "Основа расчёта",
            discipline?.name ?: "Только введённые оценки",
            listOf("Только введённые оценки") + data.disciplines.map { it.name },
            onSelect = { baseIndex = it }
        )
        Text("Сколько оценок получено", fontSize = 15.sp, color = AppColors.Text, fontWeight = FontWeight.Bold)
        grades.forEach { g -> CountRow(g, counts.getValue(g)) { setCount(g, it) } }

        ResultCard(
            title = "Средний балл",
            value = AverageFormatter.format(result),
            note = if (total == 0) "Оценок нет — добавьте хотя бы одну"
            else gradesCount(total) + " · среднее арифметическое",
            tone = ResultTone.Info
        )
        if (discipline != null) {
            Text(
                "«${discipline.name}»: сейчас " + AverageFormatter.format(current) +
                    ", с новыми оценками " + AverageFormatter.format(result),
                fontSize = 15.sp, color = AppColors.Text, fontWeight = FontWeight.Bold
            )
        }
        if (total > 0) {
            Text("Если следующая оценка…", fontSize = 15.sp, color = AppColors.Text, fontWeight = FontWeight.Bold)
            (3..5).forEach { next ->
                val withNext = GradeCalculator.averageWithAdded(base, counts + (next to (counts.getValue(next) + 1)))
                ScenarioRow(next, AverageFormatter.format(withNext), GradeCalculator.isLow(withNext))
            }
        }
        AppButton(
            "Сбросить",
            onClick = { c5 = 0; c4 = 0; c3 = 0; c2 = 0 },
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            kind = ButtonKind.Secondary
        )
    }
}

// ---------------------------------------------------------------- Целевой балл (спринт 5)

/** Максимальная длина введённого числа: хватает для «4,75», не даёт вставить длинный мусор. */
private const val MAX_TARGET_LENGTH = 6

@Composable
private fun TargetCalculator(data: AppData) {
    if (data.disciplines.isEmpty()) {
        EmptyState("Дисциплин пока нет", "Калькулятор работает по оценкам дисциплины")
        return
    }
    var index by rememberSaveable { mutableStateOf(0) }
    var targetText by rememberSaveable { mutableStateOf("4,20") }
    val discipline = data.disciplines[index.coerceIn(0, data.disciplines.lastIndex)]
    val values = data.gradesOf(discipline.id).map { it.value }
    val current = GradeCalculator.average(values)
    val trimmed = targetText.trim()
    val target = trimmed.replace(',', '.').toBigDecimalOrNull()
    val result = target?.let { GradeCalculator.requiredNextGrade(values, it) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        AppDropdown("Дисциплина", discipline.name, data.disciplines.map { it.name }, onSelect = { index = it })
        AppTextField(
            "Желаемый средний",
            targetText,
            onValueChange = { if (it.length <= MAX_TARGET_LENGTH) targetText = it },
            keyboardType = KeyboardType.Decimal
        )
        Text(
            "Сейчас: " + AverageFormatter.format(current) + " · " + gradesCount(values.size),
            fontSize = 15.sp, color = AppColors.Text, fontWeight = FontWeight.Bold
        )

        when {
            trimmed.isEmpty() -> ResultCard("Введите желаемый средний балл", null, "Например, 4,5", ResultTone.Warn)
            result == null -> ResultCard("Это не число", null, "Введите значение от 2 до 5, например 4,5", ResultTone.Warn)
            result is TargetResult.Needed -> ResultCard(
                "Нужна следующая оценка", result.grade.toString(),
                "чтобы средний стал не ниже ${trimmed.replace('.', ',')}", ResultTone.Info
            )
            result is TargetResult.AlreadyAchieved -> ResultCard(
                "Цель уже достигнута", null,
                "Даже с оценкой ${GradeRules.MIN_GRADE} средний не опустится ниже ${trimmed.replace('.', ',')}", ResultTone.Good
            )
            result is TargetResult.Unreachable -> ResultCard(
                "Цель недостижима одной оценкой", null,
                "Нужна ${result.required}, а максимум ${GradeRules.MAX_GRADE}. Потребуется несколько оценок", ResultTone.Warn
            )
            else -> ResultCard(
                "Цель вне диапазона", null,
                "Целевой балл должен быть от ${GradeRules.MIN_GRADE} до ${GradeRules.MAX_GRADE}", ResultTone.Warn
            )
        }
    }
}

private const val MAX_COUNT = 99

@Composable
private fun CountRow(grade: Int, count: Int, onChange: (Int) -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(AppColors.Surface)
            .border(1.dp, AppColors.Border, shape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "Оценка $grade",
            fontWeight = FontWeight.Bold,
            fontSize = 17.sp,
            color = AppColors.Text,
            modifier = Modifier.weight(1f)
        )
        StepButton("−", enabled = count > 0) { onChange(count - 1) }
        Text(
            count.toString(),
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = AppColors.Text,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 6.dp).size(width = 36.dp, height = 24.dp)
        )
        StepButton("+", enabled = count < MAX_COUNT) { onChange(count + 1) }
    }
}

@Composable
private fun StepButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .alpha(if (enabled) 1f else 0.6f)
            .size(36.dp)
            .clip(RoundedCornerShape(9.dp))
            .background(AppColors.PrimarySoft)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = AppColors.PrimaryDark)
    }
}

@Composable
private fun ScenarioRow(next: Int, average: String, low: Boolean) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(AppColors.Surface)
            .border(1.dp, AppColors.Border, shape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("Оценка $next", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = AppColors.Text)
        Chip(average, low)
    }
}
