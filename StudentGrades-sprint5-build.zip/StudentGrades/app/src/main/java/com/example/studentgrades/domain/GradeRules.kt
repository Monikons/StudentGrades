package com.example.studentgrades.domain

/** Единые правила оценивания (docs/rules-and-model.md). Менять только здесь. */
object GradeRules {
    const val MIN_GRADE = 2
    const val MAX_GRADE = 5

    /** Знаков после запятой при показе среднего. */
    const val AVERAGE_SCALE = 2

    /** Средний балл ниже этого значения считается низким (подсветка красным). */
    const val LOW_AVERAGE_THRESHOLD = "3.50"
}
