package com.example.studentgrades.domain

import java.math.BigDecimal
import java.math.RoundingMode

/** Расчёты среднего балла (спринт 4). Все веса оценок одинаковы. */
object GradeCalculator {

    /** Среднее арифметическое, 2 знака, HALF_UP. null — если оценок нет (деления на ноль нет). */
    fun average(values: List<Int>): BigDecimal? {
        if (values.isEmpty()) return null
        return BigDecimal(values.sum())
            .divide(BigDecimal(values.size), GradeRules.AVERAGE_SCALE, RoundingMode.HALF_UP)
    }

    /** Общий средний: сумма всех оценок / число всех оценок (не среднее средних). */
    fun overallAverage(allValues: List<Int>): BigDecimal? = average(allValues)

    /**
     * Сценарный расчёт: средний балл, если к оценкам [base] добавить оценки из [added]
     * (ключ — оценка 2–5, значение — сколько раз она получена). Оценок нет — null.
     */
    fun averageWithAdded(base: List<Int>, added: Map<Int, Int>): BigDecimal? {
        val extra = added.flatMap { (grade, count) -> List(count.coerceAtLeast(0)) { grade } }
        return average(base + extra)
    }
}
