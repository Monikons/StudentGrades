package com.example.studentgrades.ui.calculator

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.studentgrades.data.AppData
import com.example.studentgrades.domain.AverageFormatter
import com.example.studentgrades.domain.GradeCalculator
import com.example.studentgrades.domain.GradeRules
import com.example.studentgrades.ui.components.AppButton
import com.example.studentgrades.ui.components.AppDropdown
import com.example.studentgrades.ui.components.ButtonKind
import com.example.studentgrades.ui.components.Chip
import com.example.studentgrades.ui.components.ScreenBar
import com.example.studentgrades.ui.components.gradesCount
import com.example.studentgrades.ui.theme.AppColors

/**
 * Калькулятор среднего балла (сценарный прогноз, усложнение спринта 4).
 * Студент выбирает, сколько оценок 2, 3, 4 и 5 получено, и видит средний балл.
 * Можно взять за основу оценки дисциплины: тогда расчёт покажет, каким станет её средний балл.
 */
@Composable
fun CalculatorScreen(data: AppData) {
    val grades = (GradeRules.MIN_GRADE..GradeRules.MAX_GRADE).toList().reversed() // 5, 4, 3, 2
    var counts by remember { mutableStateOf(grades.associateWith { 0 }) }
    var baseIndex by remember { mutableStateOf(0) } // 0 — без основы, дальше — дисциплины

    val base: List<Int> = if (baseIndex == 0) emptyList()
    else data.disciplines.getOrNull(baseIndex - 1)?.let { d -> data.gradesOf(d.id).map { it.value } } ?: emptyList()
    val baseName = if (baseIndex == 0) null else data.disciplines.getOrNull(baseIndex - 1)?.name

    val result = GradeCalculator.averageWithAdded(base, counts)
    val total = base.size + counts.values.sum()
    val current = GradeCalculator.average(base)

    Column(Modifier.fillMaxSize()) {
        ScreenBar("Калькулятор среднего балла")
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            AppDropdown(
                "Основа расчёта",
                baseName ?: "Только введённые оценки",
                listOf("Только введённые оценки") + data.disciplines.map { it.name },
                onSelect = { baseIndex = it }
            )
            Text("Сколько оценок получено", fontSize = 15.sp, color = AppColors.TextSecondary, fontWeight = FontWeight.Medium)
            grades.forEach { g ->
                CountRow(
                    grade = g,
                    count = counts.getValue(g),
                    onChange = { counts = counts + (g to it.coerceIn(0, MAX_COUNT)) }
                )
            }

            // Итог (.res): большое число и пояснение
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(AppColors.Primary)
                    .padding(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Средний балл", color = Color.White.copy(alpha = 0.9f), fontSize = 15.sp)
                Text(
                    AverageFormatter.format(result),
                    color = Color.White,
                    fontSize = 45.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    if (total == 0) "Оценок нет — добавьте хотя бы одну"
                    else gradesCount(total) + " · среднее арифметическое",
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center
                )
            }

            if (baseName != null) {
                Text(
                    "«$baseName»: сейчас " + AverageFormatter.format(current) + ", с новыми оценками " +
                        AverageFormatter.format(result),
                    fontSize = 15.sp,
                    color = AppColors.TextSecondary, fontWeight = FontWeight.Medium
                )
            }

            // Сценарии: какой будет средний, если следующая оценка 3, 4 или 5
            if (total > 0) {
                Text("Если следующая оценка…", fontSize = 15.sp, color = AppColors.TextSecondary, fontWeight = FontWeight.Medium)
                (3..5).forEach { next ->
                    val withNext = GradeCalculator.averageWithAdded(
                        base,
                        counts + (next to (counts.getValue(next) + 1))
                    )
                    ScenarioRow(next, AverageFormatter.format(withNext))
                }
            }

            AppButton(
                "Сбросить",
                onClick = { counts = grades.associateWith { 0 } },
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                kind = ButtonKind.Secondary
            )
        }
    }
}

private const val MAX_COUNT = 99

@Composable
private fun CountRow(grade: Int, count: Int, onChange: (Int) -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(AppColors.Surface)
            .border(1.dp, AppColors.Border, shape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "Оценка $grade",
            fontWeight = FontWeight.Bold,
            fontSize = 17.sp,
            color = AppColors.Text,
            modifier = Modifier.weight(1f)
        )
        StepButton("−", enabled = count > 0) { onChange(count - 1) }
        Text(
            count.toString(),
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = AppColors.Text,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 6.dp).size(width = 36.dp, height = 24.dp)
        )
        StepButton("+", enabled = count < MAX_COUNT) { onChange(count + 1) }
    }
}

@Composable
private fun StepButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .alpha(if (enabled) 1f else 0.45f)
            .size(36.dp)
            .clip(RoundedCornerShape(9.dp))
            .background(AppColors.PrimarySoft)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = AppColors.PrimaryDark)
    }
}

@Composable
private fun ScenarioRow(next: Int, average: String) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(AppColors.Surface)
            .border(1.dp, AppColors.Border, shape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("Оценка $next", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = AppColors.Text)
        Chip(average)
    }
}
