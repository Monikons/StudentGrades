package com.example.studentgrades.domain

import java.math.BigDecimal

/** Единый формат среднего балла: запятая, 2 знака; «—», если оценок нет. */
object AverageFormatter {
    const val EMPTY = "—"

    fun format(average: BigDecimal?): String =
        average?.toPlainString()?.replace('.', ',') ?: EMPTY
}
