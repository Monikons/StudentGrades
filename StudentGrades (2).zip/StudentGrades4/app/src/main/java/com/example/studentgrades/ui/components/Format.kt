package com.example.studentgrades.ui.components

import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

/** Полная дата в форме: 12.11.2026. */
val DateFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy")

/** Короткая дата в списке оценок: 12.11 (как в макете). */
val ShortDateFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM")

private val Ru: Locale = Locale.forLanguageTag("ru")

/** «1 оценка», «2 оценки», «5 оценок». */
fun gradesCount(n: Int): String {
    val m100 = n % 100
    val m10 = n % 10
    val word = when {
        m100 in 11..14 -> "оценок"
        m10 == 1 -> "оценка"
        m10 in 2..4 -> "оценки"
        else -> "оценок"
    }
    return "$n $word"
}

/** «Ноябрь 2026». */
fun monthLabel(month: YearMonth): String =
    month.month.getDisplayName(TextStyle.FULL_STANDALONE, Ru)
        .replaceFirstChar { it.uppercase() } + " " + month.year

/** «Ноябрь» (без года) — для строк динамики. */
fun monthName(month: YearMonth): String =
    month.month.getDisplayName(TextStyle.FULL_STANDALONE, Ru).replaceFirstChar { it.uppercase() }

/** «Ноя» — подпись под столбиком графика. */
fun monthShort(month: YearMonth): String =
    month.month.getDisplayName(TextStyle.SHORT_STANDALONE, Ru)
        .replaceFirstChar { it.uppercase() }.trimEnd('.')
