package com.example.studentgrades.ui.disciplines

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.studentgrades.data.AppData
import com.example.studentgrades.domain.AverageFormatter
import com.example.studentgrades.ui.components.EmptyState
import com.example.studentgrades.ui.components.ListRow
import com.example.studentgrades.ui.components.ScreenBar

/** Экран 2. Список дисциплин. */
@Composable
fun DisciplinesScreen(data: AppData, onOpenGrades: (Long) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ScreenBar("Дисциплины")
        if (data.disciplines.isEmpty()) {
            EmptyState("Дисциплин пока нет", "Добавьте первую дисциплину, чтобы вносить оценки")
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                items(data.disciplines, key = { it.id }) { d ->
                    val avg = data.averageOf(d.id)
                    ListRow(
                        title = d.name,
                        subtitle = d.teacherName ?: "—",
                        chip = AverageFormatter.format(avg),
                        onClick = { onOpenGrades(d.id) }
                    )
                }
            }
        }
    }
}
