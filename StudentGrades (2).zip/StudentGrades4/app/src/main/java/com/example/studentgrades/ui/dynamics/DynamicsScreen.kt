package com.example.studentgrades.ui.dynamics

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.studentgrades.data.AppData
import com.example.studentgrades.domain.AverageFormatter
import com.example.studentgrades.domain.GradeCalculator
import com.example.studentgrades.ui.components.Chip
import com.example.studentgrades.ui.components.EmptyState
import com.example.studentgrades.ui.components.ScreenBar
import com.example.studentgrades.ui.components.monthName
import com.example.studentgrades.ui.components.monthShort
import com.example.studentgrades.ui.theme.AppColors
import java.math.BigDecimal
import java.time.YearMonth

/** Экран 6. Динамика: средний балл по календарным месяцам (месяцы без оценок пропускаются). */
@Composable
fun DynamicsScreen(data: AppData) {
    val points: List<Pair<YearMonth, BigDecimal>> = data.grades
        .groupBy { YearMonth.from(it.date) }
        .toSortedMap()
        .mapNotNull { (month, list) -> GradeCalculator.average(list.map { it.value })?.let { month to it } }

    Column(Modifier.fillMaxSize()) {
        ScreenBar("Динамика")
        if (points.isEmpty()) {
            EmptyState("Данных пока нет", "Динамика появится после первых оценок")
            return@Column
        }
        val shape = RoundedCornerShape(12.dp)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)
        ) {
            // .chart
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(165.dp)
                    .clip(shape)
                    .background(AppColors.Surface)
                    .border(1.dp, AppColors.Border, shape)
                    .padding(start = 21.dp, end = 21.dp, top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(18.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                points.forEach { (_, avg) ->
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight(avg.toFloat() / 5f)
                            .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                            .background(AppColors.ChartBar)
                    )
                }
            }
            // .axis
            Row(
                Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 12.dp, start = 21.dp, end = 21.dp),
                horizontalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                points.forEach { (month, _) ->
                    Text(
                        monthShort(month),
                        fontSize = 15.sp,
                        color = AppColors.TextSecondary, fontWeight = FontWeight.Medium,
                        modifier = Modifier.weight(1f),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
            // изменение к прошлому месяцу (.row)
            points.zipWithNext().reversed().forEach { (prev, cur) ->
                val diff = cur.second.subtract(prev.second)
                val sign = if (diff.signum() >= 0) "+" else ""
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 9.dp)
                        .clip(shape)
                        .background(AppColors.Surface)
                        .border(1.dp, AppColors.Border, shape)
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            monthName(prev.first) + " → " + monthName(cur.first),
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = AppColors.Text
                        )
                        Text("изменение", fontSize = 15.sp, color = AppColors.TextSecondary, fontWeight = FontWeight.Medium)
                    }
                    Chip(sign + AverageFormatter.format(diff))
                }
            }
            if (points.size < 2) {
                Text(
                    "Для сравнения нужно два месяца с оценками",
                    fontSize = 15.sp,
                    color = AppColors.TextSecondary, fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
