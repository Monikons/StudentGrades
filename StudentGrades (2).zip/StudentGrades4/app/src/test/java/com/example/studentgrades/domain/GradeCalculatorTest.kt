package com.example.studentgrades.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.math.BigDecimal

class GradeCalculatorTest {
    private val sample = listOf(5, 4, 3, 5)

    @Test fun average_example_from_task() =
        assertEquals(BigDecimal("4.25"), GradeCalculator.average(sample))

    @Test fun average_empty_is_null() = assertNull(GradeCalculator.average(emptyList()))

    @Test fun average_rounds_half_up() {
        assertEquals(BigDecimal("4.67"), GradeCalculator.average(listOf(5, 5, 4)))
        assertEquals(BigDecimal("2.67"), GradeCalculator.average(listOf(3, 2, 3)))
    }

    @Test fun test_data_averages() {
        assertEquals(BigDecimal("4.60"), GradeCalculator.average(listOf(5, 4, 5, 4, 5)))
        assertEquals(BigDecimal("4.00"), GradeCalculator.average(listOf(4, 4, 4, 4)))
        assertEquals(BigDecimal("5.00"), GradeCalculator.average(listOf(5, 5)))
    }

    @Test fun overall_is_sum_over_count_not_average_of_averages() {
        // дисциплины: 5 и 2,2,2,2 → общий 13 / 5 = 2,60, а не (5 + 2) / 2 = 3,50
        assertEquals(BigDecimal("2.60"), GradeCalculator.overallAverage(listOf(5, 2, 2, 2, 2)))
    }

    @Test fun overall_for_test_data_is_4_07() {
        val all = listOf(5, 4, 5, 4, 5, 4, 4, 4, 4, 3, 2, 3, 5, 5)
        assertEquals(BigDecimal("4.07"), GradeCalculator.overallAverage(all))
    }

    @Test fun scenario_counts_only() {
        // две пятёрки и две тройки: 16 / 4 = 4,00
        assertEquals(BigDecimal("4.00"), GradeCalculator.averageWithAdded(emptyList(), mapOf(5 to 2, 3 to 2)))
    }

    @Test fun scenario_with_base() {
        // физика 4,4,4,4 + одна пятёрка: 21 / 5 = 4,20
        assertEquals(BigDecimal("4.20"), GradeCalculator.averageWithAdded(listOf(4, 4, 4, 4), mapOf(5 to 1)))
    }

    @Test fun scenario_nothing_is_null() =
        assertNull(GradeCalculator.averageWithAdded(emptyList(), mapOf(2 to 0, 3 to 0, 4 to 0, 5 to 0)))

    @Test fun formatter_uses_comma_and_dash() {
        assertEquals("4,25", AverageFormatter.format(BigDecimal("4.25")))
        assertEquals("—", AverageFormatter.format(null))
    }
}
